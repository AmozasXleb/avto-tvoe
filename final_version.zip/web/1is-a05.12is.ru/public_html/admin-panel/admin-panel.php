<?php

require_once ('../php-scripts/connections.php');

?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="../bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <link href="../css/header-footer-css.css" rel="stylesheet">
    <link href="../css/admin.css" rel="stylesheet">
    <link rel="icon" href="../img/logo.ico">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>
    <title>АдминПанель - АвтоТвоё</title>
</head>

<body>

    <div class="Header">
        <img class="logo" src="../img/big-logo.png">
        <div class="Menu">
            <span style="color: white; font-family: Russo One">АДМИН ПАНЕЛЬ</span>
            <div class="wrapper-btns" id="comp-btn">
                <button class="btn-menu" onclick="ZP()">Статусы заказов</button>
            </div>
            <div class="wrapper-btns" id="comp-btn">
                <button class="btn-menu" onclick="KP()">Категории товаров</button>
            </div>
            <div class="wrapper-btns" id="comp-btn">
                <button class="btn-menu" onclick="RP()">Редактирование товаров</button>
            </div>
        </div>
    </div>

    <div class="main_content container-xl">
        <div id="status-zakazov">
            <div class="zag">Статус заказов</div>
            <table>
                <thead>
                    <tr>
                        <th class="info">Информация о заказе</th>
                        <th>Статус</th>
                        <th>Функции</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                    require_once ('../php-scripts/zakazi_bd.php');

                    ?>
            </table>
        </div>

        <div id="kategorii-tovarov" hidden>
            <div class="zag">Категории товаров</div>
            <table>
                <thead>
                    <tr>
                        <th class="info">Категория</th>
                        <th>Тег категории</th>
                        <th>Функции</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                    require_once ('../php-scripts/kategory_bd.php');

                    ?>
            </table>

            <div class="minizag">Добавить категорию:</div>
            <form action="../php-scripts/join_things.php" method="get">
                <table>
                    <thead>
                        <tr>
                            <th class="info">Категория</th>
                            <th>Тег категории</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <input type="text" placeholder="Категория..." name="kategoria" id="kategories">
                            </td>
                            <input name="towhere" value="kategories" hidden>
                            <td>
                                <input type="text" placeholder="Тег..." name="tag">
                            </td>
                        </tr>
                </table>
                <div class="dob-btn">
                    <button>Добавить</button>
                </div>
            </form>
        </div>

        <div id="redaktor" hidden>
            <div class="zag">Редактирование товаров</div>

            <table>
                <thead>
                    <tr>
                        <th>id</th>
                        <th>Категория</th>
                        <th>Имя товара</th>
                        <th>Цена</th>
                        <th>Описание</th>
                        <th>Производитель</th>
                        <th>Год</th>
                        <th>Модель</th>
                        <th>Картинка (путь к ней)</th>
                        <th>
                            Удалить товар
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                    require_once ('../php-scripts/tovar_bd.php');

                    ?>
            </table>

            <div class="minizag">Добавить товары:</div>
            <form action="../php-scripts/join_things.php" method="get">
                <table>
                    <tbody>
                        <tr>
                            <input name="towhere" value="tovar" hidden>
                            <td>id</td>
                            <td>
                                <input class="in-tovar" type="text" placeholder="Категория..." name="kategoria"
                                    id="tovar">
                            </td>
                            <td>
                                <input class="in-tovar" type="text" placeholder="Имя..." name="name">
                            </td>
                            <td>
                                <input class="in-tovar" type="text" placeholder="Цена..." name="price">
                            </td>
                            <td>
                                <input class="in-tovar" type="text" placeholder="Описание..." name="opis">
                            </td>
                            <td>
                                <input class="in-tovar" type="text" placeholder="Производитель..." name="proiz">
                            </td>
                            <td>
                                <input class="in-tovar" type="text" placeholder="Год.." name="year">
                            </td>
                            <td>
                                <input class="in-tovar" type="text" placeholder="Модель.." name="model">
                            </td>
                            <td>
                                <input class="in-tovar" type="text" placeholder="Путь.." name="src">
                            </td>
                        </tr>
                </table>
                <div class="dob-btn">
                    <button>Добавить</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const zakazPanel = document.getElementById('status-zakazov');
        const kategoriiPanel = document.getElementById('kategorii-tovarov');
        const redaktorPanel = document.getElementById('redaktor');

        function ZP() {
            zakazPanel.hidden = false;
            kategoriiPanel.hidden = true;
            redaktorPanel.hidden = true;
        }

        function KP() {
            zakazPanel.hidden = true;
            kategoriiPanel.hidden = false;
            redaktorPanel.hidden = true;
        }

        function RP() {
            zakazPanel.hidden = true;
            kategoriiPanel.hidden = true;
            redaktorPanel.hidden = false;
        }
    </script>



</body>

</html>