<?php require_once ('php-scripts/connections.php'); ?>
<?php require_once ('php-scripts/session.php') ?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <link href="css/header-footer-css.css" rel="stylesheet">
    <link href="css/katalog.css" rel="stylesheet">
    <link rel="icon" href="img/logo.ico">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>КАТАЛОГ - АвтоТвоё - автозапчасти</title>

</head>

<body>

    <?php require_once ("php-patterns/header.php") ?>

    <div class="main_content container-xl">
        <div class="poisk" hidden>
            <form action="/search" method="get">
                <span>Поиск:</span>
                <input type="text">
                <button>Найти</button>
            </form>
        </div>

        <div class="kat-fil">
            <div class="sub">
                <span>Категории</span>
                <button id="clear" onclick="Clear()">Очистить категории</button>
            </div>
            <div class="main">
                <button class="Btn E3E3E3" id="avto" onclick="selectKat()">
                    Автодетали
                </button>
                <button class="Btn FB550F" id="acc" onclick="selectKat()">
                    Аксессуары
                </button>
                <button class="Btn Ffffff" id="masla" onclick="selectKat()">
                    Масла и лаки
                </button>
            </div>
        </div>

        <div class="kat-fil">
            <div class="sub">
                <span>Фильтры</span>
                <button id="clear" onclick="clearFil()">Очистить фильтры</button>
            </div>
            <div class="main">
                <button class="Btn ora" id="year" onclick="selectFil('year')">
                    Год производства
                </button>

                <button class="Btn ora" id="name" onclick="selectFil('name')">
                    Наименование
                </button>
                <button class="Btn ora" id="price" onclick="selectFil('price')">
                    Цена
                </button>
            </div>
        </div>

        <div class="main_catalog">
            <?php

            $stmt2 = $pdo->prepare('SELECT * FROM tovar');

            $stmt2->execute();

            $results = $stmt2->fetchAll(PDO::FETCH_ASSOC);

            foreach ($results as $row) {
                echo "                        
                            <div class='KartochkaTovara' name='tag' value='" . $row['tag'] . "'>                          
                                <div class='ImgTovar'>                              
                                    <img class='TovarImg' src='" . $row['src'] . "' />                         
                                </div>                         
                                <div class='TextTovara' name='year' value='" . $row['year'] . "'>                              
                                    <div class='zag-tovara' name='name' value='" . $row['name'] . "'>                                   
                                        " . $row['name'] . "</div>                            
                                    <div class='price'>                               
                                        " . $row['price'] . " руб</div>   
                                    <div class='more'>
                                        <form  action='tovar-card.php' method='GET'>                                   
                                            <button class='btn-more' id='more-btn' name='id' value='" . $row['id'] . "'>Подробнее</button>
                                        </form>  
                                    ";
                                        if (!in_array($row['id'], $_SESSION['id_tovarov'])) {
                                            echo "<button class='btn-more red' id='in-kor-btn' name='id' value='" . $row['id'] . "'  onclick='addItemToSession(" . $row['id'] . ", this)'>В корзину</button>";
                                        } else {
                                        echo "
                                        <button class='btn-more red' id='in-kor-btn' name='id' hidden>В корзине</button>";
                                        }
                                        ;
                                        echo "  
                                    </div>             
                                </div>                       
                            </div>";
            }

            ?>
        </div>
    </div>

    <?php require_once ("php-patterns/footer.php") ?>

    <script>
        function addItemToSession(idTovar, element) {
            fetch('php-scripts/update_korz.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id_tovar=' + encodeURIComponent(idTovar)
            })
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    if (data.status === 'success') {
                        alert(data.message);
                        element.hidden = true;
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        }
    </script>

    <script>

        var values = [];
        var divs = [];
        var divs_new = [];
        var divs_fil = {};
        var mainBlock;
        var parentBlock;

        function findDivsByNameAndValue(name, value) {
            values.push(value);
            $(`div[name="${name}"]`).each(function () {
                if (values.includes($(this).attr('value'))) {
                    $(this).prop('hidden', false);
                }
                else {
                    this.setAttribute('hidden', '');
                }
            });
        }

        function showAll(name) {
            $(`div[name="${name}"]`).each(function () {
                $(this).prop('hidden', false);
                values.length = 0;
            });
        }

        function selectKat() {
            const btn = event.target;
            const btnId = event.target.id;
            if (btn.style.border === '9px solid black') {
                showAll('tag');
                btn.style.border = "none";
            } else if (btn.style.border !== '9px solid black') {
                btn.style.border = '9px black solid'
                findDivsByNameAndValue('tag', btnId);
            }
        }

        function selectFil(filter) {
            const btn = event.target;
            const btnId = event.target.id;
            if (btn.style.border === '9px solid black') {
                btn.style.border = "none";
            } else if (btn.style.border !== '9px solid black') {
                const button = event.target;
                const parentBlock = button.parentNode;
                const mainBlock = parentBlock.parentNode;
                const btns = mainBlock.querySelectorAll('.Btn');

                for (let i = 0; i < btns.length; i++) {
                    const node = btns[i];
                    node.style.border = "none";
                }
                btn.style.border = '9px black solid';
                $.ajax({
                    url: 'php-scripts/filters.php',
                    method: 'POST',
                    data: { data: btnId },
                    success: function (response) {
                        $('.KartochkaTovara').remove();
                        $('.main_catalog').append(response); у
                    }
                });


            }
        }

        function clearFil() {
            location.reload();
        }

        function Clear(params) {
            const button = event.target;
            const parentBlock = button.parentNode;
            const mainBlock = parentBlock.parentNode;

            const btns = mainBlock.querySelectorAll('.Btn');

            for (let i = 0; i < btns.length; i++) {
                const node = btns[i];
                node.style.border = "none";
            }

            showAll('tag');
        }
    </script>

</body>

</html>