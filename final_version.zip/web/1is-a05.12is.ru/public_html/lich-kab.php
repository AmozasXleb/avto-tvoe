<?php require_once ('php-scripts/session.php') ?>

<?php require ('php-scripts/connections.php') ?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <link href="css/header-footer-css.css" rel="stylesheet">
    <link href="css/lich-kab.css" rel="stylesheet">
    <link rel="icon" href="img/logo.ico">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>
    <title>ЛИЧНЫЙ КАБИНЕТ - АвтоТвоё - автозапчасти</title>

</head>

<body>

    <?php require_once ("php-patterns/header.php") ?>

    <div class="main_content container-xl">
        <div class="zagolovok">Личный кабинет</div>
        <div class="main_blocks">
            <div class="btns-menu">
                <button id="infa" onclick="Infa()">Основная информация</button>
                <button id="korz" onclick="Korz()">Корзина</button>
                <button id="zakazi" onclick="Zakazi()">Заказы</button>
                <div id="itogo" hidden>
                    <span class="itogo-text">ИТОГО:</span>
                    <div>
                        <span class="itogo-text-sm">Сумма: </span>
                        <span id="summa">2134565 руб</span>
                    </div>
                </div>
            </div>
            <div id="user-infa">
                <div class="icon-png">
                    <img src="img/icon-lich-kabinet.png">
                </div>
                <div class="infa">
                    <?php

                    $id_user = $_SESSION['user_id'];

                    $stmt2 = $pdo->prepare('SELECT * FROM users WHERE id = ' . $id_user . '');

                    $stmt2->execute();

                    $results = $stmt2->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($results as $row) {
                        echo ' 
                    <div сlass="text-block">
                        <span class="zag">Имя: </span><span id="infa-text">' . $row['name'] . '</span>
                    </div>
                    <div сlass="text-block">
                        <span class="zag">Фамилия: </span><span id="infa-text">' . $row['fam'] . '</span>
                    </div>
                    <div сlass="text-block">
                        <span class="zag">Отчество: </span><span id="infa-text">' . $row['fam2'] . '</span>
                    </div>
                    <div сlass="text-block">
                        <span class="zag">Логин: </span><span id="infa-text">' . $row['login'] . '</span>
                    </div>
                    <div сlass="text-block">
                        <span class="zag">Почта: </span><span id="infa-text">' . $row['mail'] . '</span>
                    </div>
                    <div сlass="text-block">
                        <span class="zag">Пароль: </span><span id="infa-text">********</span>
                    </div>';
                    }

                    ?>
                    <form action="php-scripts\logout.php">
                        <button id="close-acc">
                            Выйти
                        </button>
                    </form>
                </div>
            </div>
            <div id="user-korz" hidden>
                <?php

                $length = count($_SESSION['id_tovarov']);

                for ($i = 0; $i < $length; $i++) {

                    $tovarId = $_SESSION['id_tovarov'][$i];
                    $tovarKolvo = $_SESSION['kolvo_tovarov'][$i];

                    $stmt2 = $pdo->prepare('SELECT * FROM tovar WHERE id = :tovarId');
                    $stmt2->execute(['tovarId' => $tovarId]);
                    $results = $stmt2->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($results as $row) {
                        echo '<div class="tovar-line" id="tovar">
                            <img class="img-tovara" src=' . $row['src'] . '>
                            <div class="opisanie-tovara">
                                <div id="name">
                                    ' . $row['name'] . '
                                </div>
                                <div id="price">
                                    ' . $row['price'] . ' руб.
                                </div>
                                <div id="number-tovarov">
                                    х' . $tovarKolvo . '
                                </div>
                                <div class="btns-tovar-line">
                                    <button class="btn" id="less-one" name="id" value="' . $row['id'] . '" onclick="noMore(' . $row['id'] . ', this);">
                                        Удалить
                                    </button>
                                    <button class="btn" id="more-one" name="id" value="' . $row['id'] . '" onclick="addMore(' . $row['id'] . ', this);">
                                        Добавить
                                    </button>
                                </div>
                            </div>
                        </div>';
                    }

                }

                ?>

                <form id="submit">
                    <label for="exampleFormControlInput1" class="form-label">Ваш пароль для подтверждения:</label>
                    <input type="text" class="form-control" id="password" placeholder="пароль..." required>
                </form>
                <div class="btn-make-zakaz">
                    <button id="make-zakaz" onclick="formZakaz()">
                        Сформировать заказ
                    </button>
                </div>
            </div>
            <div id="user-zakazi" hidden>
                <?php

                $id = $_SESSION['user_id'];
                $stmt2 = $pdo->prepare('SELECT * FROM orders WHERE id_user = :id');
                $stmt2->execute(['id' => $id]);
                $results = $stmt2->fetchAll(PDO::FETCH_ASSOC);

                foreach ($results as $row) {
                    echo '<div class="zakaz-line">
                        <div class="opisanie-zakaza">
                            <div class="text" id="date">
                                Заказ от ' . $row['date'] . '
                            </div>
                            <div class="text green" id="status">
                                ' . $row['status'] . '
                            </div>
                            <div class="text" id="kolvo">
                                ' . $row['number_of_tovars'] . ' товар(-а, -ов)
                            </div>
                            <div class="text" id="summa-zakaza">
                                ' . $row['summa'] . ' руб.
                            </div>
                            <div class="btn-del">
                                <button id="delete" onclick="deleteZakaz(' . $row['id'] . ')">
                                    Отменить
                                </button>
                            </div>
                        </div>
                    </div>';
                }
                ?>
            </div>
        </div>
    </div>

    <?php require_once ("php-patterns/footer.php") ?>

    <script>

        // Функция для поиска всех элементов с заданным id
        function findAllElementsById(id) {
            return document.querySelectorAll(`#${id}`);
        }

        function deleteZakaz(id) {
            fetch('php-scripts/delete-zakaz.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id_zakaz=' + encodeURIComponent(id)
            })
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    if (data.status === 'success') {
                        alert('Заказ отменен.');
                        window.location.href = 'lich-kab.php';
                    } else {
                        // alert(data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        }


        function updateSum() {
            var sum = 0;
            var elements = findAllElementsById('price');
            elements.forEach(element => {
                var parentElement = element.parentElement;
                var numberTovarovElement = parentElement.querySelector('#number-tovarov');
                var kolvoText = numberTovarovElement.innerText.replace('х', '').trim();
                var kolvo = parseInt(kolvoText);
                price = parseInt(element.innerText.replace(' руб', ''));
                oneThing = price * kolvo;
                sum = sum + oneThing;
            });
            var itog = document.getElementById('summa');
            itog.innerText = sum + ' руб';
            console.log(sum);
        }

        document.addEventListener('DOMContentLoaded', function () {
            updateSum();
        });

        function addMore(idTovar, element) {
            var numberTovarov = element.closest('.btns-tovar-line').previousElementSibling;
            var kolvo = numberTovarov.innerText.replace('х', '');
            fetch('php-scripts/addMore.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id_tovar=' + encodeURIComponent(idTovar) + '&kolvo_tovar=' + encodeURIComponent(kolvo)
            })
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    if (data.status === 'success') {
                        kolvo = 'х' + (parseInt(kolvo) + 1);
                        numberTovarov.innerText = kolvo;
                        updateSum();
                    } else {
                        // alert(data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        function noMore(idTovar, element) {
            var numberTovarov = element.closest('.btns-tovar-line').previousElementSibling;
            var kolvo = numberTovarov.innerText.replace('х', '');
            fetch('php-scripts/noMore.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id_tovar=' + encodeURIComponent(idTovar) + '&kolvo_tovar=' + encodeURIComponent(kolvo)
            })
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    if (data.status === 'success') {
                        if (kolvo == 1) {
                            var prev = numberTovarov.parentElement;
                            var prev2 = prev.parentElement;
                            prev2.remove();
                        } else {
                            kolvo = 'х' + (parseInt(kolvo) - 1);
                            numberTovarov.innerText = kolvo;
                            updateSum();
                        }

                    } else {
                        // alert(data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        }



        function formZakaz() {
            var password = document.getElementById('password').value;
            var itog = document.getElementById('summa');
            var summa = itog.innerText;
            fetch('php-scripts/form_order.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'summa=' + encodeURIComponent(summa) + '&password=' + encodeURIComponent(password)
            })
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    if (data.status === 'success') {

                        alert('Ваш товар ожидает доставки. Статутс вы можете посмотреть в вкладке "Заказы".')
                        window.location.href = 'lich-kab.php';
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        }

    </script>

    <script>
        const infa = document.getElementById('user-infa');
        const korz = document.getElementById('user-korz');
        const zakazi = document.getElementById('user-zakazi');

        const infaBTN = document.getElementById('infa');
        const korzBTN = document.getElementById('korz');
        const zakaziBTN = document.getElementById('zakazi');

        const itogPanel = document.getElementById('itogo');

        function Infa() {
            infa.hidden = false;
            korz.hidden = true;
            zakazi.hidden = true;
            itogPanel.hidden = true;
            infaBTN.style.backgroundColor = '#FFE2D0';
            korzBTN.style.backgroundColor = '#FF9351';
            zakaziBTN.style.backgroundColor = '#FF9351';
        }

        function Korz() {
            infa.hidden = true;
            korz.hidden = false;
            zakazi.hidden = true;
            itogPanel.hidden = false;
            infaBTN.style.backgroundColor = '#FF9351';
            korzBTN.style.backgroundColor = '#FFE2D0';
            zakaziBTN.style.backgroundColor = '#FF9351';
        }

        function Zakazi() {
            infa.hidden = true;
            korz.hidden = true;
            zakazi.hidden = false;
            itogPanel.hidden = true;
            zakaziBTN.style.backgroundColor = '#FFE2D0';
            korzBTN.style.backgroundColor = '#FF9351';
            infaBTN.style.backgroundColor = '#FF9351';
        }
    </script>


</body>

</html>