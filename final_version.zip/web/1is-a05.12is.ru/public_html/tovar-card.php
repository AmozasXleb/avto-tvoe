<?php require_once ('php-scripts/connections.php') ?>
<?php require_once ('php-scripts/session.php') ?>

<!DOCTYPE html>
<html lang='ru'>

<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <link href='bootstrap-5.3.3-dist/css/bootstrap.min.css' rel='stylesheet'>
    <script src='bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js'></script>
    <link href='css/header-footer-css.css' rel='stylesheet'>
    <link href='css/tovar-card.css' rel='stylesheet'>
    <link rel='icon' href='img/logo.ico'>
    <script src='https://code.jquery.com/jquery-3.6.0.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js'></script>
    <title>ТОВАР - АвтоТвоё - автозапчасти</title>

</head>

<body>

    <?php require_once ('php-patterns/header.php') ?>

    <?php

    $stmt2 = $pdo->prepare('SELECT * FROM tovar');

    $stmt2->execute();

    $results = $stmt2->fetchAll(PDO::FETCH_ASSOC);

    $id = $_GET['id'];

    foreach ($results as $row) {
        if ($row['id'] == $id) {
            echo "<div class='main_content container-xl'>
        <div class='KartochkaTovara'>
            <div class='ImgTovar'>
                <img class='TovarImg' src='" . $row['src'] . "' />
            </div>
            <div class='TextTovara'>
                <div class='zag-tovara'>
                    " . $row['name'] . "</div>
                <div class='price'>" . $row['price'] . " руб</div>
                <div class='opis'>
                    <p>" . $row['opisanie'] . "</p>
                    <p>Год произовдства: " . $row['year'] . "</p>
                    <p>Производитель: " . $row['maker'] . "</p>
                    <p>Модель: " . $row['model'] . "</p>
                </div>";
            if (in_array($row['id'], $_SESSION['id_tovarov'])) {
                echo "
                <div class='more'>
                    <button class='btn-more red' id='in-kor-btn'>В корзине</button>
                </div>";
            } else {
                echo "
                    <div class='more'>
                        <button class='btn-more red' id='in-kor-btn' onclick='addItemToSession(" . $row['id'] . ")'>В корзину</button>
                    </div>";
            }
            ;
            echo "
            </div>
        </div>
    </div>

    <div class='Opisanie5'>
            <div>
                <img src='img/shest.png'>
            </div>
            <div class='text'>
                Наша миссия - помочь вам сохранить ваш автомобиль в идеальном состоянии, обеспечить его безопасность и
                комфорт, а также помочь вам выразить свой индивидуальный стиль. Мы работаем для вас, и мы готовы помочь
                вам в любое время.</div>
            <div>
                <img src='img/shest.png'>
            </div>
        </div>";
        }
    }
    ;

    ?>

    <script>
        function addItemToSession(idTovar) {
            fetch('php-scripts/update_korz.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id_tovar=' + encodeURIComponent(idTovar)
            })
            .then(response => response.json())
                .then(data => {
                    console.log(data);
                    if (data.status === 'success') {
                        alert(data.message);
                        element.hidden = true;
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        }
    </script>
    
    <?php require_once ('php-patterns/footer.php') ?>

</body>

</html>