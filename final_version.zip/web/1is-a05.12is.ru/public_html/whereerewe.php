<?php require_once ('php-scripts/session.php') ?>

<!DOCTYPE html>
<html lang="ru">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
  <link href="css/header-footer-css.css" rel="stylesheet">
  <link href="css/whereerewe.css" rel="stylesheet">
  <link rel="icon" href="img/logo.ico">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <title>ГДЕ НАС НАЙТИ - АвтоТвоё - автозапчасти</title>

</head>

<body>

  <?php require_once ("php-patterns/header.php") ?>

  <div class="main_content container-xl">
    <div class="Opisanie">
      <div class="text">
        <div class="sposobi">
          С нами можно связаться разными способами:<br />
          <ul>
            <li>+7(342) 244-89-21</li>
            <li>ppk4@mail.ru</li>
          </ul>
          </div>
        <div class="ikonki">
          <img class="sicon" src="img/vk.png" />
          <img class="sicon" src="img/tg.png" />
          <img class="sicon" src="img/odnokl.png" />
          <img class="sicon" src="img/dzen.png" />
          <img class="sicon" src="img/mail.png" />
        </div>
      </div>
      <img class="logo_op" src="img/лого.png" />
    </div>
    <div class="Opisanie">
      <div class="text">
        <div class="sposobi">
          Или приезжайте к нам на точку продаж напрямую!<br /><br />Выдача товаров так же происходит тут:<br />Пермь,
          улица Пушкина 107а.</div>
      </div>
      <div class="map">
      <script type="text/javascript" charset="utf-8" async
        src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A525eaadc20bb3d2ed2fbcdad5946a9d242850cad859aef3a910f502600e1a45c&amp;width=100%&amp;height=400&amp;lang=ru_RU&amp;scroll=true"></script>
      </div>
      </div>
  </div>

  <?php require_once ("php-patterns/footer.php") ?>

</body>

</html>