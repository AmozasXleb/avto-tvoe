<?php require('php-scripts/session.php') ?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <link href="css/header-footer-css.css" rel="stylesheet">
    <link href="css/about.css" rel="stylesheet">
    <link rel="icon" href="img/logo.ico">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <title>ГЛАВНАЯ - АвтоТвоё - автозапчасти</title>

</head>

<body>

    <?php require_once ("php-patterns/header.php") ?>

    <div class="main_content container-xl">
        <img class="AdBunner"  src="img/ad-bunner.png">
        <div class="Opisanie1" >
            <img class="ImgDet"  src="img/img-det.png" />
            <div style="width: 477px;"><span
                    style="color: #C10606; font-size: 20px; font-family: Inter; font-weight: 700; word-wrap: break-word">АвтоТвоё</span><span
                    style="color: black; font-size: 20px; font-family: Inter; font-weight: 400; word-wrap: break-word">
                    - это современный онлайн-магазин автомобильных запчастей и аксессуаров, предлагающий широкий
                    ассортимент товаров для любых марок и моделей автомобилей. Наша команда профессионалов тщательно
                    отбирает только лучшие продукты от ведущих производителей, чтобы обеспечить нашим клиентам высокое
                    качество и надежность.</span></div>
        </div>
        <div class="Opisanie2" >
            <div style="width: 448px; text-align: center"><span
                    style="color: black; font-size: 20px; font-family: Inter; font-weight: 400; word-wrap: break-word">В
                    нашем магазине вы найдете </span><span
                    style="color: #CB0000; font-size: 20px; font-family: Inter; font-weight: 400; word-wrap: break-word">всё</span><span
                    style="color: black; font-size: 20px; font-family: Inter; font-weight: 400; word-wrap: break-word">,<br />что
                    нужно: </span></div>

            <div class="Btns">
                <div class="Btn" id="E3E3E3">
                    <div>Автодетали</div>
                </div>
                <div class="Btn" id="FB550F">
                    <div>Аксессуары</div>
                </div>
                <div class="Btn" id="Ffffff">
                    <div>Масла и лаки</div>
                </div>
            </div>
        </div>

        <div class="Opisanie3">
            <div class="Iconki">
                <img class="Sdek" src="img/sdek.png" />
                <img class="PochtaRossii" src="img/pochta-rossii.png" />
                <img class="YaDostavka" src="img/ya-dostavka.png" />
            </div>
            <div class="text">
                Мы ценим каждого клиента и стремимся обеспечить ему максимальный комфорт при покупке. Поэтому мы
                предлагаем удобную систему поиска товаров, быструю доставку, а также круглосуточную поддержку клиентов.
            </div>
        </div>

        <div class="Opisanie4">
            <div class="text"><span
                    style="color: #980000; font-size: 32px; font-family: Inter; font-weight: 700; word-wrap: break-word">Новинки</span><span
                    style="color: black; font-size: 32px; font-family: Inter; font-weight: 400; word-wrap: break-word">
                    в ассортименте товаров каждые две недели:</span></div>
            <div class="swiper">
                <div class="swiper-wrapper">
                        <?php require("php-patterns/kartochka-tovara.php"); ?>
                </div>
            </div>
        </div>

        <script>
            const swiper = new Swiper('.swiper', {
                // Optional parameters
                direction: 'horizontal',
                loop: true,
                speed: 800,
                spaceBetween: 10,

                autoplay: {
                    delay: 1000,
                }
            });
        </script>

        <div class="Opisanie5">
            <div>
                <img src="img/shest.png">
            </div>
            <div class="text">
                Наша миссия - помочь вам сохранить ваш автомобиль в идеальном состоянии, обеспечить его безопасность и
                комфорт, а также помочь вам выразить свой индивидуальный стиль. Мы работаем для вас, и мы готовы помочь
                вам в любое время.</div>
            <div>
                <img src="img/shest.png">
            </div>
        </div>
    </div>

    <?php require_once ("php-patterns/footer.php") ?>

</body>

</html>