<?php require_once ('php-scripts/session.php') ?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <link href="css/header-footer-css.css" rel="stylesheet">
    <link href="css/reg-avto.css" rel="stylesheet">
    <link rel="icon" href="img/logo.ico">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>РЕГИСТРАЦИЯ\АВТОРИЗАЦИЯ - АвтоТвоё - автозапчасти</title>
</head>

<body>

    <?php require_once ("php-patterns/header.php") ?>

    <div class="fon">
        <div class="main_content container-xl">
            <div class="mini-logo">
                <img src="img/logo.png">
            </div>
            <div class="osnova">
                <div class="zag-forms">
                    <span>Добро пожаловать!</span>
                    <div>
                        <button id="reg isUsed" onclick="changePanels()">Регистрация</button>
                        |
                        <button id="avto" onclick="changePanels()">Авторизация</button>
                    </div>
                </div>

                <form id="regist" class="forma" action="php-scripts/registration.php" method="get">
                    <div>
                        <label for="exampleFormControlInput1" class="form-label">*Имя</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Имя..." required>
                    </div>
                    <div>
                        <label for="exampleFormControlInput1" class="form-label">*Фамилия</label>
                        <input type="text" class="form-control" name="fam" id="fam" placeholder="Фамилия.." required>
                    </div>
                    <div>
                        <label for="exampleFormControlInput1" class="form-label">Отчество</label>
                        <input type="text" class="form-control" name="fam2" id="fam2" placeholder="Отчество...">
                    </div>
                    <div>
                        <label for="exampleFormControlInput1" class="form-label">*Логин</label>
                        <input type="text" class="form-control" name="log" id="log" placeholder="Логин..." required>
                    </div>
                    <div>
                        <label for="exampleFormControlInput1" class="form-label">*Электронная почта</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="name@example.com" required>
                    </div>
                    <div>
                        <label for="exampleFormControlInput1" class="form-label">*Пароль</label>
                        <input type="password" class="form-control" name="par" id="par" placeholder="От 8 символов" required>
                    </div>
                    <div>
                        <label for="exampleFormControlInput1" class="form-label">*Повтор пароля</label>
                        <input type="password" class="form-control" name="par2" id="par_two" placeholder="От 8 символов" required>
                    </div>

                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" required>
                        <label class="form-check-label" for="flexCheckDefault">
                            *Прочитайте наши условия пользования, и если вы согласны, поставьте галочку.
                        </label>
                    </div>

                    <button>Зарегестрироваться</button>
                </form>

                <form id="avtor" class="forma" hidden action="php-scripts/avtorization.php" method="get">
                    <div>
                        <label for="exampleFormControlInput1" class="form-label">*Логин</label>
                        <input type="text" class="form-control" id="login" name="login" placeholder="Логин..." required>
                    </div>
                    <div>
                        <label for="exampleFormControlInput1" class="form-label">*Пароль</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="пароль......." required>
                    </div>

                    <button>Войти</button>
                </form>
                </divм>
            </div>
        </div>

        <?php require_once ("php-patterns/footer.php") ?>


        <script>
            const regForm = document.getElementById('regist');
            const avtoForm = document.getElementById('avtor');

            function changePanels() {
                if (regForm.hidden) {
                    regForm.hidden = false;
                    avtoForm.hidden =true;
                } else {
                    regForm.hidden = true;
                    avtoForm.hidden =false;
                }
            }

        </script>

</body>

</html>