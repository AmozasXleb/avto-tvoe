<?php

$stmt3 = $pdo->prepare('SELECT * FROM kategories');

// Execute the query
$stmt3->execute();

// Fetch all the results
$results = $stmt3->fetchAll(PDO::FETCH_ASSOC);

// Print the results
foreach ($results as $row) {
    echo '<tr>
            <td>
                <p>' . $row['name'] . '</p>
            </td>
            <td>
                ' . $row['tag'] . '
            </td>
            <td class="funcs">
                    <form action="../php-scripts/delete_things.php" method="get">
                        <input value="' . $row['id'] . '" name="id" hidden>
                        <input value="kategories" name="towhere" hidden>
                        <button>Удалить</button>
                    </form>
            </td>
        </tr>';
}


?>