<?php

require ('connections.php');

// Create a new PDO instance
$pdo = new PDO($dsn, $username, $password);

// Set the PDO error mode to exceptions
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$table = $_GET['towhere'];
$kategory = $_GET['kategoria'];
$tag = $_GET['tag'];
$name = $_GET['name'];
$price = $_GET['price'];
$opis = $_GET['opis'];
$proiz = $_GET['proiz'];
$year = $_GET['year'];
$model = $_GET['model'];
$src = $_GET['src'];

if ($table == 'tovar') {
    $query = "INSERT INTO tovar (tag, name, price, opisanie, maker, year, model, src) VALUES (:tag, :name, :price, :opis, :proiz, :year, :model, :src)";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":name", $name);
    $stmt->bindParam(":price", $price);
    $stmt->bindParam(":opis", $opis);
    $stmt->bindParam(":proiz", $proiz);
    $stmt->bindParam(":year", $year);
    $stmt->bindParam(":model", $model);
    $stmt->bindParam(":src", $src);
    $stmt->bindParam(":tag", $kategory);
    $stmt->execute();
} else if ($table == "kategories") {
    $query = "INSERT INTO kategories (tag, name) VALUES (:tag, :name)";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":name", $kategory);
    $stmt->bindParam(":tag", $tag);
    $stmt->execute();
}


echo "<script>window.location.href = '../admin-panel/admin-panel';</script>";

?>