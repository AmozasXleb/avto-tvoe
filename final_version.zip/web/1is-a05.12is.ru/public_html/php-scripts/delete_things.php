<?php

require ('connections.php');

// Create a new PDO instance
$pdo = new PDO($dsn, $username, $password);

// Set the PDO error mode to exceptions
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$table = $_GET['towhere'];
$id = $_GET['id'];

if ($table == 'tovar') {
    $query = "DELETE FROM tovar WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $id);
    $stmt->execute();
} else if ($table == "kategories") {
    $query = "DELETE FROM kategories WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $id);
    $stmt->execute();
} else if ($table == "orders") {
    $query = "DELETE FROM orders WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $id);
    $stmt->execute();
}

echo "<script>window.location.href = '../admin-panel/admin-panel';</script>";

?>