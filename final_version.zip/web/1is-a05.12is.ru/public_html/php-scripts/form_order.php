<?php

require_once ("session.php");
require ('connections.php');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $summa = $_POST['summa'];
    $password = $_POST['password'];
    $kolvo = array_sum($_SESSION['kolvo_tovarov']);
    $currentDate = date('Y-m-d');
    $id = $_SESSION['user_id'];
    $status = 'В ПУТИ';
    $is_approved = 0;

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id');
    $stmt->execute(['id' => $id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);


    if ($result['password'] == $password) {
        $query = "INSERT INTO orders (date, id_user, number_of_tovars, summa, status, is_approved) VALUES (:date, :user_id, :kolvo, :summa, :status, :is_approved)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(":date", $currentDate);
        $stmt->bindParam(":user_id", $id);
        $stmt->bindParam(":kolvo", $kolvo);
        $stmt->bindParam(":summa", $summa);
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":is_approved", $is_approved);
        $stmt->execute();

        $_SESSION['id_tovarov'] = [];
        $_SESSION['kolvo_tovarov'] = [];

        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'no_allowed', 'message' => 'Неправильный пароль, повторите попытку. ' . $password . '']);
    }



} else {
    echo json_encode(['status' => 'error', 'message' => 'Некорректный запрос']);
}

?>