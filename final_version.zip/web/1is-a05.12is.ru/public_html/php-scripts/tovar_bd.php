<?php

$stmt2 = $pdo->prepare('SELECT * FROM tovar');

$stmt2->execute();

$results = $stmt2->fetchAll(PDO::FETCH_ASSOC);

foreach ($results as $row) {
    echo '<tr>
    <td>' . $row['id'] . '</td>
    <td>' . $row['tag'] . '</td>
    <td>' . $row['name'] . '</td>
    <td>' . $row['price'] . '</td>
    <td>' . $row['opisanie'] . '</td>
    <td>' . $row['maker'] . '</td>
    <td>' . $row['year'] . '</td>
    <td>' . $row['model'] . '</td>
    <td>' . $row['src'] . '</td>
    <form action="../php-scripts/delete_things.php" method="get">
    <input value="' . $row['id'] . '" name="id" hidden>
    <input value="tovar" name="towhere" hidden>
    <td><button>Удалить товар</button></td>
    </form>
</tr>';
}



?>
