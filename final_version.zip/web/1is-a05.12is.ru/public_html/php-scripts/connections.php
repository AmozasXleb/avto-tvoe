<?php
ini_set('display_errors',  0);
$dsn = 'mysql:host=31.129.99.31;dbname=1is-a05_1is-a05';
$username = '1is-a05_1is-a05';
$password = 'Lololoshka1';

// Create a new PDO instance
$pdo = new PDO($dsn, $username, $password);

// Set the PDO error mode to exceptions
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

?>