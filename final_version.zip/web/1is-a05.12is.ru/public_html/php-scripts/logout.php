<?php

require_once ('session.php');

require_once ('connections.php');

$_SESSION['korz'][] = array_combine($_SESSION['id_tovarov'], $_SESSION['kolvo_tovarov']);

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$jsonData = json_encode($_SESSION['korz']);
$jsonData = str_replace(['[', ']'], '', $jsonData);
$jsonData = str_replace(['"Array":;'], '', $jsonData);
$jsonData = str_replace(['"Array":'], '', $jsonData);
$id = $_SESSION['user_id'];

$stmt = $pdo->prepare('SELECT * FROM korz WHERE user_id = :id');
$stmt->execute(['id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
// Устанавливаем атрибут ошибок для PDO

// Получаем текущий ID пользователя из сессии
$id = $_SESSION['user_id'];

// Подготавливаем запрос для удаления строки с указанным user_id
$stmt_delete = $pdo->prepare('DELETE FROM korz WHERE user_id = :id');
$stmt_delete->execute(['id' => $id]);
$stmt = $pdo->prepare("INSERT INTO korz (tovars, user_id) VALUES (:jsonData, :id)");
$stmt->bindParam(':jsonData', $jsonData);
$stmt->bindParam(':id', $id);
$stmt->execute();

$_SESSION['id_tovarov'] = [];

$_SESSION['kolvo_tovarov'] = [];
$_SESSION['user_id'] = 'none';
$_SESSION['korz'] = [];

echo "<script>window.location.href = '../about.php';</script>";

?>