<?php

require ('connections.php');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

// Set the PDO error mode to exceptions
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$id = $_POST['id_zakaz'];

$query = "DELETE FROM orders WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->bindParam(":id", $id);
$stmt->execute();
}
echo json_encode(['status' => 'success']);

?>