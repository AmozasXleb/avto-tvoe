<?php

require('connections.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $stmt2 = $pdo->prepare('SELECT * FROM tovar');

    $stmt2->execute();

    $results = $stmt2->fetchAll(PDO::FETCH_ASSOC);

    $filter = $_POST['data'];

    if ($filter === 'name') {

        usort($results, function ($a, $b) {
            return strcmp($a['name'], $b['name']);
        });
    } elseif ($filter === 'price') {

        usort($results, function ($a, $b) {
            return $a['price'] - $b['price'];
        });
    } elseif ($filter === 'year') {

        usort($results, function ($a, $b) {
            return $a['year'] - $b['year'];
        });
    }


    foreach ($results as $row) {
        echo "                        
                    <div class='KartochkaTovara' name='tag' value='" . $row['tag'] . "'>                          
                        <div class='ImgTovar'>                              
                            <img class='TovarImg' src='" . $row['src'] . "' />                         
                        </div>                         
                        <div class='TextTovara' name='year' value='" . $row['year'] . "'>                              
                            <div class='zag-tovara' name='name' value='" . $row['name'] . "'>                                   
                                " . $row['name'] . "</div>                            
                            <div class='price' name='price' value='" . $row['price'] . "'>                               
                                " . $row['price'] . " руб</div>                             
                            <div class='more' name='id' value='" . $row['id'] . "'>                                   
                                <button class='btn-more' id='more-btn'>Подробнее</button>
                                <button class='btn-more red' id='in-kor-btn'>В корзину</button>
                            </div>                            
                        </div>                       
                    </div>";
    }
}

?>