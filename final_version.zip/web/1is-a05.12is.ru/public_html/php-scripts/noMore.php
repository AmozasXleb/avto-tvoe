<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id_tovar']) && isset($_POST['kolvo_tovar'])) {

    $id_tovar = $_POST['id_tovar'];
    $kolvo_tovar = $_POST['kolvo_tovar'];

    $kolvo_tovar--;

    for ($i = 0; $i < count($_SESSION['id_tovarov']); $i++) {
        if ($_SESSION['id_tovarov'][$i] == $id_tovar) {
            if ($kolvo_tovar <= 0) {
                $_SESSION['id_tovarov'][$i] = [];
                $_SESSION['kolvo_tovarov'][$i] = [];
            } else {
                $_SESSION['kolvo_tovarov'][$i] = $kolvo_tovar;
            }
        }
    }
    echo json_encode(['status' => 'success']);

} else {
    echo json_encode(['status' => 'error', 'message' => 'Некорректный запрос']);
}
?>