<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id_tovar'])) {
    $id_tovar = $_POST['id_tovar'];

    if ($_SESSION['user_id'] == 'none') {
        echo json_encode(['status' => 'error', 'message' => 'Зайдите в свою учетную запись для изменения корзины.']);
    } else {
        if (!in_array($id_tovar, $_SESSION['id_tovarov'])) {

            $_SESSION['id_tovarov'][] = $id_tovar;
            $_SESSION['kolvo_tovarov'][] = 1;
            echo json_encode(['status' => 'success', 'message' => 'Товар добавлен']);
        }
    }

} else {
    echo json_encode(['status' => 'error', 'message' => 'Некорректный запрос']);
}

?>