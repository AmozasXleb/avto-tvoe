<?php

require_once ("session.php");
require ('connections.php');

$login = $_GET['login'];
$password = $_GET['password'];

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stmt = $pdo->prepare('SELECT * FROM users WHERE login = :login AND password = :password');
$stmt->execute(['login' => $login, 'password' => $password]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    echo $result['password'];
    if ($result['password'] == $password) {
        $_SESSION['user_id'] = $result['id'];
        echo "<script>window.location.href = '../lich-kab.php';</script>";
    } else {
        echo "<script>alert('неверный логин или пароль!!');</script>";
        echo "<script>window.location.href = '../reg-avto.php';</script>";
    }
} else {
    echo "<script>alert('неверный логин или пароль!!');</script>";
    echo "<script>window.location.href = '../reg-avto.php';</script>";
}

$id = $_SESSION['user_id'];

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $pdo->prepare('SELECT * FROM korz WHERE user_id = :id');
$stmt->execute(['id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

$details = json_decode($result['tovars'], true);

$keys = array_keys($details);
$values = array_values($details);
$_SESSION['id_tovarov'] = $keys;
$_SESSION['kolvo_tovarov'] = $values;


?>