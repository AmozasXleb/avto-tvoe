<?php 

require_once("session.php");
require('connections.php');

$name = $_GET['name'];
$fam = $_GET['fam'];
$fam2 = $_GET['fam2'];
$log = $_GET['log'];
$email = $_GET['email'];
$par = $_GET['par'];
$par_two = $_GET['par2'];

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($par == $par_two) {
    $query = "INSERT INTO users (name, fam, fam2, login, mail, password) VALUES (:name, :fam, :fam2, :login, :mail, :password)";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":name", $name);
    $stmt->bindParam(":fam", $fam);
    $stmt->bindParam(":fam2", $fam2);
    $stmt->bindParam(":login", $log);
    $stmt->bindParam(":mail", $email);
    $stmt->bindParam(":password", $par);
    $stmt->execute();

    $stmt2 = $pdo->prepare('SELECT * FROM users ORDER BY id DESC LIMIT 1');
    $stmt2->execute();
    $result = $stmt2->fetch(PDO::FETCH_ASSOC);

    $_SESSION['user_id'] = $result['id'];
    echo "<script>window.location.href = '../lich-kab.php';</script>";
} else
{
    echo"<script> alert('неверный пароль!'); </script>";
    echo "<script>window.location.href = '../reg-avto.php';</script>";
}
    // $query = "INSERT INTO users (name, fam, fam2, log, email, par) VALUES (:name, :fam, :fam2, :log, :email, :par)";
    // $stmt = $pdo->prepare($query);
    // $stmt->bindParam(":name", $name);
    // $stmt->bindParam(":fam", $fam);
    // $stmt->bindParam("fam2", $fam2);
    // $stmt->bindParam(":log", $log);
    // $stmt->bindParam(":email", $email);
    // $stmt->bindParam(":par", $par);
    // $stmt->execute();

?>