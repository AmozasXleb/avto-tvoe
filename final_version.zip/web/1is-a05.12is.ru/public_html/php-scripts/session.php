<?php 

session_start();

require_once('connections.php');

if(!isset($_SESSION['user_id']))
{
    $_SESSION['user_id'] = "none";
}
if (!isset($_SESSION['id_tovarov'])) {
    $_SESSION['id_tovarov'] = [];
}
if (!isset($_SESSION['kolvo_tovarov'])) {
    $_SESSION['kolvo_tovarov'] = [];
}
if (!isset($_SESSION['id_tovarov_buyed'])) {
    $_SESSION['id_tovarov_buyed'] = [];
}

?>

