<?php

require ('connections.php');

// Create a new PDO instance
$pdo = new PDO($dsn, $username, $password);

// Set the PDO error mode to exceptions
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$id = $_GET['id'];

$stmt = $pdo->prepare('UPDATE orders SET is_approved = 1 WHERE id = :id');
$stmt->bindParam(':id', $id);
$stmt->execute();

echo "<script>window.location.href = '../admin-panel/admin-panel';</script>";

?>