<?php

$stmt = $pdo->prepare('SELECT * FROM orders');


$stmt->execute();


$results = $stmt->fetchAll(PDO::FETCH_ASSOC);


foreach ($results as $row) {
    echo '<tr>
            <td>
                <p>Заказ от ' . $row['date'] . '</p>
                <p>';
                $id_user = $row['id_user'];
                $stmt2 = $pdo->prepare('SELECT id, name, fam, fam2 FROM users WHERE id = :id_user');
                $stmt2->bindParam(":id_user", $id_user);
                $stmt2->execute();
                $results2 = $stmt2->fetchAll(PDO::FETCH_ASSOC);
                foreach ($results2 as $row2) {
                   if ($results['id_user'] == $results2['id']) {
                    echo $row2['name'];
                    echo ' ';
                    echo $row2['fam'];
                    echo ' ';
                    echo $row2['fam2'];
                    echo ' ';
                   }
                };
                echo '</p>
                <p>' . $row['number_of_tovars'] . ' товара</p>
                <p>' . $row['summa'] . ' руб</p>
            </td>
            <td>
                ' . $row['status'] . '
            </td>
            <td class="funcs">
            <form action="../php-scripts/submit_order.php" method="get">';
            if ($row['is_approved'] == "0") {
                echo' <button name="id" value="' . $row['id'] . '" id="sub">Подтвердить</button>';
            }
            echo '</form>
            <form action="../php-scripts/delete_things.php" method="get">
                <button name="id" value="' . $row['id'] . '">Отменить</button>
                <input value="orders" name="towhere" hidden>
            </form>
            </td>
        </tr>';
}



?>
