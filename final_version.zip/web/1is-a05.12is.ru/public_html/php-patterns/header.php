<?php

echo '<div class="Header">
        <img class="logo" src="img/big-logo.png">
        <div class="Menu">
            <div class="wrapper-btns" id="comp-btn">
                <a class="btn-menu" href="/about">О нас</a>
            </div>
            <div class="wrapper-btns" id="comp-btn">
                <a class="btn-menu" href="/whereerewe">Где нас найти?</a>
            </div>
            <div class="wrapper-btns" id="comp-btn">
                <a class="btn-menu" href="/katalog">Каталог</a>
            </div>
            <div class="LoginLichKabinet">
                <div class="wrapper-for-icon" id="comp-btn">
            ';
if ($_SESSION['user_id'] == 'none') {
    echo '<a href="reg-avto">
                    <img class="icon" src="img/profile-icon.png">
                </a>';
} else {
    echo '<a href="lich-kab">
                    <img class="icon" src="img/profile-icon.png">
                </a>';
}

echo '
                </div>
                <div class="wrapper-for-icon" id="menu-btn">
                    <button class="menu" onclick="openMobileMenu()">
                        <img class="icon menu" src="img/login-lich-kabinet.png">
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div id="mobile-menu">
        <div class="wrapper-btns">
            <a class="btn-menu" href="/about">О нас</a>
        </div>
        <div class="wrapper-btns">
            <a class="btn-menu" href="/whereerewe">Где нас найти?</a>
        </div>
        <div class="wrapper-btns">
            <a class="btn-menu" href="/katalog">Каталог</a>
        </div>
        <div class="LoginLichKabinet">
            <div class="wrapper-for-icon">
            ';
if ($_SESSION['user_id'] == 'none') {
    echo '<a href="reg-avto">
                    <img class="icon" src="img/profile-icon.png">
                </a>';
} else {
    echo '<a href="lich-kab">
                    <img class="icon" src="img/profile-icon.png">
                </a>';
}

echo '</div>
        </div>
    </div>
    <script>
        const mobileMenu = document.getElementById("mobile-menu");
        const mobileBtn = document.getElementById("menu-btn");

        function widthCheck() {
            const width = window.innerWidth;
            if (width <= 730) {
                mobileBtn.style.display = "block";
                console.log("то");
            } else {
                mobileBtn.style.display = "none";
                console.log("не то");
            }
        }

        function openMobileMenu() {
            if (mobileMenu.style.height === "0px" || mobileMenu.style.height === "") {
                mobileMenu.style.height = "300px";
                mobileMenu.style.transition = "height 0.6s ease-in-out";
            } else {
                mobileMenu.style.height = "0px";
                mobileMenu.style.transition = "height 0.6s ease-in-out";
            }
        }

        // Call widthCheck when the script is first loaded
        widthCheck();

        // Call widthCheck every time the screen is resized
        window.addEventListener("resize", widthCheck);
    </script>';

?>