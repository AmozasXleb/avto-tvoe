<?php

echo "                        
<div class='KartochkaTovara'>                          
<div class='ImgTovar'>                              
<img class='TovarImg' src='../tovari-assets/1.webp' />                         
</div>                         
<div class='TextTovara'>                              
<div class='zag-tovara'>                                   
Animal Auto Фильтр масляный</div>                            
<div class='price'>                               
381 руб</div>                             
<div class='more'>                                   
<button class='btn-more' id='more-btn' >Подробнее</button>
<button class='btn-more red' id='in-kor-btn'>В корзину</button>
</div>                            
</div>                       
</div>";

?>