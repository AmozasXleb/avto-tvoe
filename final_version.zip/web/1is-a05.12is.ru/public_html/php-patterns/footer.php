<?php 

echo '    <div class="Footer">
        <div class="footer-zag">
            <a href="/about" class="footer-zag">АвтоТвоё</a>
        </div>
        <div class="footer-zag">
            <a href="/about" class="footer-zag">О нас</a>
        </div>
        <div class="footer-zag">
            <a class="footer-zag" href="/katalog" class="footer-zag">
                Каталог</a>
            <a class="under-zag" href="/katalog">
                Новинки</a>
            <a class="under-zag" href="/katalog">
                Товары</a>
        </div>
        <div class="footer-zag">
            <a href="/whereerewe" class="footer-zag">
                Где нас найти?</a>
            <a class="under-zag" href="/whereerewe">
                Контакты</a>
            <a class="under-zag" href="/whereerewe">
                Адрес</a>
        </div>
        <div class="footer-zag">
            <a href="/lich-kab" class="footer-zag">
                Личный кабинет</a>
            <a class="under-zag" href="/lich-kab">
                Корзина</a>
            <a class="under-zag" href="/lich-kab">
                Заказы</a>
        </div>
    </div>';

?>