<?php

$dsn = 'mysql:host=31.129.99.31;dbname=1is-a05_1is-a05';
$username = '1is-a05_1is-a05';
$password = 'Lololoshka1';

// Create a new PDO instance
$pdo = new PDO($dsn, $username, $password);

// Set the PDO error mode to exceptions
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt2 = $pdo->prepare('SELECT * FROM tovar');

$stmt2->execute();

$results = $stmt2->fetchAll(PDO::FETCH_ASSOC);

$kolvo = 0;

foreach ($results as $row) {
    if ($kolvo !=5) {
        echo "<div class='swiper-slide'>
        <div class='KartochkaTovara'>                          
        <div class='ImgTovar'>                              
        <img class='TovarImg' src='../" . $row['src'] . "' />                         
        </div>                         
        <div class='TextTovara'>                              
        <div class='zag-tovara'>                                   
        " . $row['name'] . "</div>                            
        <div class='price'>                               
        " . $row['price'] . " руб</div>                                                       
        </div>                       
        </div>
        </div>";
        $kolvo++;
    }
}

?>